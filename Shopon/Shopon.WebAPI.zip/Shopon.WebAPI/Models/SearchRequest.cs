﻿namespace Shopon.WebAPI.Models
{
    public class SearchRequest
    {
        public string Key { get; set; }
    }
}

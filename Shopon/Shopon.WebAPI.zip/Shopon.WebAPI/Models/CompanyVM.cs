﻿namespace Shopon.WebAPI.Models
{
    public class CompanyVM
    {
        public int CompanyId { get; set; }
        public string? CompanyName { get; set; }
    }
}

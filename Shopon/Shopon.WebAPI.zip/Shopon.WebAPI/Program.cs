using Shopon.ADO;
using Shopon.Business.Contracts;
using Shopon.Business;
using Shopon.Data.Contracts;
using Shopon.EF;
using Microsoft.EntityFrameworkCore;
using Shopon.EF.Models;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
//Services
//Product Service

builder.Services.AddScoped<IProductRepository, ProductADORepository>();
//builder.Services.AddScoped<IProductRepository, ProductEFRepository>();
builder.Services.AddScoped<IProductManager, ProductManager>();

//Product Async Service
builder.Services.AddScoped<IProductAsyncRepository, ProductAsyncEFRepository>();
builder.Services.AddScoped<IProductManager, ProductManager>();

// config EF
builder.Services.AddDbContext<DbShoponContext>(options =>
{
    options.UseSqlServer(builder.Configuration.GetConnectionString("Default"));
});

//Config Swagger
builder.Services.AddSwaggerGen();

// Company async Service
builder.Services.AddScoped<ICompanyAsyncRepository, CompanyAsyncEFRepository>();
builder.Services.AddScoped<ICompanyAsyncManager, CompanyAsyncManager>();

builder.Services.AddControllers();

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI(options =>
{
    options.SwaggerEndpoint("/swagger/v1/swagger.json", "Shopon API v1.0");
    options.RoutePrefix = string.Empty;
});

// Configure the HTTP request pipeline.

app.UseAuthorization();

app.MapControllers();

app.Run();